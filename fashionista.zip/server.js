var express = require('express');
var bp = require('body-parser');
const { idText } = require('typescript');

app = express();

app.use(bp.json());


const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://yash:yash123@cluster0.amju4.mongodb.net/tcsdb?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true });
var colluser;
var collitem;
client.connect(err => {
  const collection = client.db("tcsdb").collection("Users");
  const collection1 = client.db("tcsdb").collection("Items");
  console.log("connected", collection);
  colluser = collection;
  collitem = collection1;
  // perform actions on the collection object
  //client.close();
});


app.listen(3000, () => {
    console.log("The server has started")
})


app.post('/api/user', (req, res) => {
    var data = req.body;
    console.log(data);
    colluser.find({'uname': data['uname'], 'passw': data['passw']}).toArray().then(result => {
        console.log(data['uname']);
        console.log(data['passw']);
        if(result.length > 0){res.send(result);}
        else{res.send("result not found")}
    })
})

app.post('/api/admin', (req, res) => {
    var data = req.body;

    colluser.insertOne(data).then(result => {
        res.send("User is added");
        console.log(data['uname'])
    })
})

app.put('/api/admin', (req, res) => {
    var data = req.body;

    colluser.updateOne({ 'uname': data['uname'] }, {$set: {'passw': data['passw'], 'email': data['email']} }).then(result => {
        res.send("User is updated");
        console.log(result);
    })
})

app.delete('/api/admin', (req, res) => {
    var data = req.body;

    colluser.deleteOne({ 'uname': data['uname'], 'passw': data['passw']}).then(result => {
        res.send("User is deleted");
        console.log(result);
    })
})

app.get('/api/item', (req, res) => {
    collitem.find().toArray().then(result => {
        res.send(result);
    })
})

app.post('/api/item', (req, res) => {
    var data = req.body;

    collitem.insertOne(data).then(result => {
        res.send("Item is added");
        //console.log(result)
    })
})

app.put('/api/item', (req, res) => {
    var data = req.body;
    console.log(data['pname'])
    collitem.updateOne({ 'pname': data['pname'] }, {$set: {'price': data['price']} }).then(result => {
        res.send("Item is updated");
        //console.log(result);
    })
})

app.delete('/api/item', (req, res) => {
    var data = req.body;
    console.log(data)
    collitem.deleteOne({ 'pname': data['pname'], 'price': data['price']}).then(result => {
        res.send("Item is deleted");
        //console.log(result);
    })
})

app.post('/api/purchase', (req, res) => {
    var data = req.body;
    console.log(data)
    collitem.deleteOne({ 'name': data['name']} ).then(result => {
        res.send("Item is purchased");
    })
})

//User Registration
app.post('/api/users', (req, res) => {
    var data = req.body;

    colluser.insertOne(data).then(result => {
        res.send("User is added");
        console.log(data['uname'])
    })
})

app.get('/api/users', (req, res) => {
    var data = req.body;
    colluser.find({'uname': data['uname'], 'passw': data['passw']}).toArray().then(result => {
        console.log(result.length);
        res.send(result);
    })
})