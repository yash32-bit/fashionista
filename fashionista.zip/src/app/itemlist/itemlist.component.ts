import { Component, OnInit } from '@angular/core';
import { ItemlistService } from '../shared/itemlist.service';
import { ItemService } from '../entities/item/item.service';
import { IItem, Item } from '../entities/item/item.model'

@Component({
  selector: 'app-itemlist',
  templateUrl: './itemlist.component.html',
  styleUrls: ['./itemlist.component.css']
})
export class ItemlistComponent implements OnInit {

  items: any;

  constructor(private is: ItemService) { }

  ngOnInit(): void {
   this.is.get().subscribe(res=>{
     console.log(res);
     this.items = res
   });
  }

  addcart(id: string){
    this.is.cart(id);
  }

  purchase(name: string){
    console.log(name);
    this.is.purchase(name).subscribe(res => console.log(res));
  }

}
