import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import {IAdmin, Admin} from '../entities/admin/admin.model';
import {IUser, User} from '../entities/user/user.model'
import { AdminService} from '../entities/user/user.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  uname: string = "";
  passw: string = "";
  email: string = "";
  add: boolean = false;
  validate: boolean = true;

  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit(): void {
  }

  adddata(data){
    //this.start();
    console.log(data.uname);
    const user = new User(data.uname, data.passw, data.email, null, null);
    this.adminService.create(user).subscribe(res=>{
      console.log(res);
    });
    
  }

  validatedata(data){
    console.log(data.uname);
    const user = new User(data.uname, data.passw, null, null, null);
    this.adminService.get(user).subscribe((res)=>{console.log(res[0]); 
                                          if(res[0].uname == data.uname && res[0].passw == data.passw){localStorage.setItem('uname', data.uname); localStorage.setItem('passw', data.passw); this.router.navigateByUrl('/items')}}
                                          ,(err) => console.log(err))
  }

  adduser(){
    this.add = false;
    this.validate = true;
  }

  validateuser(){
    this.add = true;
    this.validate = false;
  }

}
