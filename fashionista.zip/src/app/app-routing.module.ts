import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { ItemlistComponent } from './itemlist/itemlist.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [

  {path: 'user', component: UserComponent},
  {path: 'admin', component: AdminComponent},
  {path: 'items', component: ItemlistComponent},
  {path: '', redirectTo: '/user', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
