import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ItemlistService {

  constructor(private http:HttpClient) { }

  getItems(){
    this.http.get('/api/item')
  }
}
