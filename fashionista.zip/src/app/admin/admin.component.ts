import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import {IAdmin, Admin} from '../entities/admin/admin.model';
import {IUser, User} from '../entities/user/user.model'
import { AdminService } from '../entities/user/user.service';
import {IItem, Item} from '../entities/item/item.model';
import { ItemService } from '../entities/item/item.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  addForm: FormGroup;
  updateForm: FormGroup;
  deleteForm: FormGroup;
  uname: string = "";
  passw: string = "";
  email: string = "";
  add: boolean = false;
  update: boolean = true;
  delete: boolean = true;
  additem: boolean = true;
  updateitem: boolean = true;
  deleteitem: boolean = true;

  constructor(private adminService: AdminService, private itemService: ItemService ,protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    //this.start();
  }

  adddata(data){
    //this.start();
    console.log(data.uname);
    const user = new User(data.uname, data.passw, data.email, null, null);
    this.adminService.create(user).subscribe(res=>console.log(res))
  }

  updatedata(data){
    //this.start();
    console.log(data.uname);
    const user = new User(data.uname, data.passw, data.email, null, null);
    this.adminService.update(user).subscribe(res=>console.log(res))
  }

  deletedata(data){
    //this.start();
    console.log(data.uname);
    const user = new User(data.uname, data.passw, data.email, null, null);
    this.adminService.delete(user).subscribe(res=>console.log(res))
  }

  addproduct(data){
    //this.start();
    console.log(data.pname);
    const item = new Item(data.pname, data.price, null);
    this.itemService.create(item).subscribe(res=>console.log(res))
  }

  updateproduct(data){
    //this.start();
    console.log(data.pname);
    const item = new Item(data.pname, data.price, null);
    this.itemService.update(item).subscribe(res=>console.log(res))
  }

  deleteproduct(data){
    //this.start();
    console.log(data.pname);
    const item = new Item(data.pname, data.price, null);
    this.itemService.delete(item).subscribe(res=>console.log(res))
  }

  start(){
    this.addForm = new FormGroup({
      uname: new FormControl(this.uname, Validators.required),
      passw: new FormControl(this.passw, Validators.required),
      email: new FormControl(this.email, Validators.required)
    })
  }

  adduser(){
    this.add = false;
    this.update = true;
    this.delete = true;
    this.additem = true;
    this.updateitem = true;
    this.deleteitem = true;
  }

  updateuser(){
    this.update = false;
    this.add = true;
    this.delete = true;
    this.additem = true;
    this.updateitem = true;
    this.deleteitem = true;
  }

  deleteuser(){
    this.update = true;
    this.add = true;
    this.delete = false;
    this.additem = true;
    this.updateitem = true;
    this.deleteitem = true;
  }

  additem1(){
    this.add = true;
    this.update = true;
    this.delete = true;
    this.additem = false;
    this.updateitem = true;
    this.deleteitem = true;
  }

  updateitem1(){
    this.add = true;
    this.update = true;
    this.delete = true;
    this.updateitem = false;
    this.additem = true;
    this.deleteitem = true;
  }

  deleteitem1(){
    this.add = true;
    this.update = true;
    this.delete = true;
    this.updateitem = true;
    this.additem = true;
    this.deleteitem = false;
  }


}
