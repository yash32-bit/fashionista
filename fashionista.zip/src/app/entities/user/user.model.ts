export interface IUser {
    _id?: string;
    uname: string;
    passw: string;
    email: string;
    cart?: [string];
  }
  
  export class User implements IUser {
    constructor(
      public uname: string,
      public passw: string,
      public email: string,
      public _id?: string,
      public cart?: [string]
    ) {
      this._id = _id ? _id : null;
      this.uname = uname;
      this.passw = passw;
      this.email = email;
      this.cart = [''];
    }
  }