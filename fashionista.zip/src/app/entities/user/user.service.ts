import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IUser, User } from './user.model';

@Injectable({
    providedIn: 'root'
})
export class AdminService {
    
    AdminUrl: string = '/api/admin';

    constructor(private http: HttpClient){}


    get(user: User){
        //var user = {"uname": uname, "passw": passw}
        console.log(user.uname);
        return this.http.post('/api/user', user);
    }

    create(user: User) {
        return this.http.post(this.AdminUrl, user);
    }

    update(user: User){
        return this.http.put(this.AdminUrl, user);
    }

    delete(user: User){
        return this.http.request('delete', this.AdminUrl, {body: user});
        //return this.http.delete(this.AdminUrl);
    }

    private error(error: any) {
        let message = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(message);
    }
}
