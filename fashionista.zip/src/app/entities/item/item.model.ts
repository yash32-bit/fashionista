export interface IItem {
    _id?: string;
    name: string;
    price: number;
  }
  
  export class Item implements IItem {
    constructor(
      public name: string,
      public price: number,
      public _id?: string
    ) {
      this._id = _id ? _id : null;
      this.name = name;
      this.price = price;
    }
  }