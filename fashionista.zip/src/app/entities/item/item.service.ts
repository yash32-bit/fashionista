import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IItem, Item } from './item.model';

@Injectable({
    providedIn: 'root'
})
export class ItemService {
    
    AdminUrl: string = '/api/item';

    constructor(private http: HttpClient){}


    /*get(user: User){
        //var user = {"uname": uname, "passw": passw}
        console.log(user.uname);
        return this.http.post('/api/user', user);
    }*/

    get(){
        return this.http.get(this.AdminUrl);
    }

    create(item: Item) {
        return this.http.post(this.AdminUrl, item);
    }

    update(item: Item){
        return this.http.put(this.AdminUrl, item);
    }

    delete(item: Item){
        console.log(item._id);
        return this.http.request('delete', this.AdminUrl, {body: item});
        //return this.http.delete(this.AdminUrl);
    }

    cart(id: string){
        console.log("Item added to the cart.");
    }

    purchase(name: string){
        return this.http.post('/api/purchase', {"name":name});
    }


    private error(error: any) {
        let message = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(message);
    }
}
