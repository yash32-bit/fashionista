import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IAdmin, Admin } from './admin.model';

@Injectable({
    providedIn: 'root'
})
export class AdminService {
    
    AdminUrl: string = '/api/users';

    constructor(private http: HttpClient){}

    create(admin: Admin) {
        
        return this.http.post(this.AdminUrl, admin);
        
        //return this.http.post(this.productsUrl, product)
        //    .toPromise()
        //    .then(response => response.json())
        //    .catch(this.error);
    }

    private error(error: any) {
        let message = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(message);
    }
}
