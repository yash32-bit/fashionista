export interface IAdmin {
  _id?: string;
  uname: string;
  passw: string;
}

export class Admin implements IAdmin {
  constructor(
    public uname: string,
    public passw: string,
    public _id?: string
  ) {
    this._id = _id ? _id : null;
    this.uname = uname;
    this.passw = passw;
  }
}